$(document).ready(function() {
	$("#submitme").click(function(){
		
		$("span").text("");
		
		var myfirst = $("#firstname").val();
		
		if(myfirst == "")
		{
			$("span").text("Must enter first name");
			
			return;
		}
		if(myfirst != "")
		{
			$("#mymessage").text(myfirst + " you want an undefined vacation");
		}
//new function
	$("#submitme").click(function(){
		
	var myfirst = $("#firstname").val();
	
	$("#mymessage").text(myfirst + " You want a " + $("#imagedesc").text());
	});
});

    $("img").mouseenter(function(){
	
	$(this).css("border", "outset 10px");
	      

});
	
	 $("img").mouseout(function(){
	
	$(this).css("border", "none");      

});
//new function
     $("#vacationimages img").click(function(){
		 
	 $("#currentimage").attr("src", $(this).attr("src"));
     $("#imagedesc").text($(this).attr("alt"));
	  
	  $("#bigimage").show("slow");
	
    
		 $("#showhidebutton").click(function(){
			 $("#bigimage").toggle("slow");
				
		 });
		 

	 });
		 
	
});