var gPlan = "";
  var pPlan = "";
 var plan = 0;
  
$(document).ready(function(){
  $("#tabs").tabs();
  $( "#datepicker" ).datepicker({showOtherMonths: true});

   $("#button").click(function(){
  
    var myFirstName = $("#first_name").val().trim();
    var myLastName = $("#last_name").val().trim();
	var myStartDate = $("#datepicker").val()
	
      if(!myFirstName)
		 {
			 $("#first_error").html("You must Enter a First Name");	 
			 $('#first_name').focus();
		 }
		 else
		 {
			  $("#first_error").html("");
	
		 }
		 
		 if(!myLastName)
		 {
			 $("#last_error").html("You must Enter a Last Name");	 
		 }
		 else
		 {
			  $("#last_error").html("");
		 }
		 
		 if(!myStartDate)
		 {
			 $("#date_error").html("Please Enter The Start Date");	 
		 }
		 else
		 {
			  $("#date_error").html("");
		 }   
	   
	   if(!myStartDate || !myLastName || !myFirstName)
	     {
			 $("#all_error").html("<strong>Please Correct Errors and Try Again</strong>");	 
		 }
		 
		 else if(myStartDate && myLastName && myFirstName)
		 {
			  $("#all_error").html("");
			  $("myform").submit();
		 }
  
        if(myStartDate && myFirstName && myLastName)
	     {
		     $("#message").css('color', 'green');
	 
	          var myMessage = "<h3>Success " + myFirstName + " " + myLastName + "<br>" 
	                  + "Use the Start Date as your Password" + "</h3>" ;
 
			 $("#message").html(myMessage);
		     return false;
		 }
		    else if(!myStartDate || !myFirstName || !myLastName)
			 {
			
			  $("#message").html("");
		     }
	
  }); //END OF CLICK
 
$(function() {

	$( ".draggable" ).draggable();
	
	$( "#droppable" ).droppable({
	
	
	
		drop: function( event, ui ) {
		
	
			if (ui.draggable.attr("id") == "gplan")
			{
				$( this )
				.addClass( "ui-state-highlight" )
				.find( "p" )
				.html( "Great Plan Picked!" )
				gPlan = $(this).html();
				plan = 1;
			}
			
		
		
		 
			if (ui.draggable.attr("id") == "pplan")
			{
				$( this )
				.addClass( "ui-state-highlight" )
				.find( "p" )
				.html( "Poor Plan Picked!" )
				 pPlan = $(this).html();
				 plan =2;
			}
			
			 
			
	}
	}); //end of droppable
	
//START OF TAB # 3

 $("#feelings").click(function(){
    
   
   
   
   if(plan==0)
	  
	  {
		  $("textarea").html("I don't know").effect("bounce", 1000);
		 
	  }
  
  if(plan!=0)
  {
    if (plan==1)
			{
				 
				 $("textarea").html("Great!").removeClass("tab3-2").addClass("tab3-1").slideUp(1000).slideDown(0);
			}
    
	if(plan==2)

     {
          $("textarea").html("My head hurts!").removeClass("tab3-1").addClass("tab3-2").effect("shake", 900);
		  
     }
	
 
 }
 
	 }); // end of feelings click	
 
   
   
   });
	
	
});//end of ready