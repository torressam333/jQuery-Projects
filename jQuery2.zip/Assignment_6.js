$(document).ready(function(){

$("#mysubmit").click(function(){
	
    var myFirstName = $("#first_name").val().trim();

    var myLastName = $("#last_name").val().trim();
	 
	 var myGenderButton = $("input[name = 'gender']:checked").val();
	  
	  var myGender = "";
		
		var myYearsExperience = $("#years").val().trim();
		
	
         if(!myFirstName)
		 {
			 $("#first_error").html("You must Enter a First Name");	 
			 $('#first_name').focus();
		 }
		 else
		 {
			  $("#first_error").html("");
	
		 }
		 
		 if(!myLastName && myFirstName)
		 {
			 $("#last_error").html("You must Enter a Last Name");	 
		 }
		 else
		 {
			  $("#last_error").html("");
		 }
	
	 
         if(!myGenderButton && myLastName && myFirstName)
	     {
		      $("#gender_error").html("You must choose a gender");	 
	      }
	    else
	     {
		      $("#gender_error").html("");
         }
		 
	    if(myYearsExperience == "-" && myGenderButton && myLastName && myFirstName)
	     {
	          $("#years_error").html("You must select a number");	 
	     }
	    else
	     {
		      $("#years_error").html("");
	     }
	   
	    if(myGenderButton == "M")
	     {
		     myGender = ("Male");
	     }
	    else if(myGenderButton == "F")
	     {
		     myGender = ("Female");
	     }
	 
	    if(myYearsExperience != "-" && myGenderButton && myLastName && myFirstName)
	     {
		     $("#message").css('background-color', 'yellow');
	 
	          var myMessage = "<h2>Employment Stats For: " + myFirstName + " " + myLastName + "</h2>" + "<br>" 
	                  +"You are a:" + myGender + "<br>"  + " You have: " + myYearsExperience 
		              + " years experience.";
 
			 $("#message").html(myMessage);
		     return false;
	     }
	 
	 
       }); //END OF CLICK
 });//END OF READY